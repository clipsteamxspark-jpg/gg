import {
  AnimatePresence,
  motion,
  useMotionValue,
  useSpring,
  useTransform,
} from "framer-motion";
import {
  Heart,
  Music2,
  Pause,
  Play,
  Sparkles,
  Stars,
  Gift,
  Coffee,
  MessageCircle,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import bgImg from "@/assets/images/valentine-bg.png";
import stickersImg from "@/assets/images/kawaii-stickers.png";
import pookieCatImg from "@/assets/images/pookie-cat.png";

type Slide = {
  id: string;
  kicker: string;
  title: string;
  body: string;
  accent?: "primary" | "accent";
  icon: any;
};

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    if (!mq) return;
    const onChange = () => setReduced(!!mq.matches);
    onChange();
    mq.addEventListener?.("change", onChange);
    return () => mq.removeEventListener?.("change", onChange);
  }, []);
  return reduced;
}

function useKeyNav(onPrev: () => void, onNext: () => void) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") onPrev();
      if (e.key === "ArrowRight" || e.key === " ") onNext();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onPrev, onNext]);
}

function FloatingElement({
  children,
  delay = 0,
  duration = 4,
}: {
  children: React.ReactNode;
  delay?: number;
  duration?: number;
}) {
  return (
    <motion.div
      animate={{
        y: [0, -20, 0],
        rotate: [-5, 5, -5],
        scale: [1, 1.05, 1],
      }}
      transition={{
        duration,
        repeat: Infinity,
        delay,
        ease: "easeInOut",
      }}
    >
      {children}
    </motion.div>
  );
}

function BackgroundHearts() {
  const hearts = useMemo(
    () =>
      Array.from({ length: 25 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: 10 + Math.random() * 30,
        delay: Math.random() * 5,
        duration: 10 + Math.random() * 20,
        opacity: 0.1 + Math.random() * 0.2,
      })),
    [],
  );

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {hearts.map((h) => (
        <motion.div
          key={h.id}
          className="absolute"
          style={{
            left: `${h.left}%`,
            top: `${h.top}%`,
            width: h.size,
            height: h.size,
          }}
          animate={{
            y: [-20, 20, -20],
            x: [-10, 10, -10],
            opacity: [h.opacity, h.opacity * 2, h.opacity],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: h.duration,
            repeat: Infinity,
            delay: h.delay,
            ease: "linear",
          }}
        >
          <Heart className="w-full h-full text-primary fill-primary/10" />
        </motion.div>
      ))}
    </div>
  );
}

function AudioControl() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(true);

  // Use a stable, high-quality romantic track from a CDN
  const songUrl ="https://mobcup.fm/ringtone/ki-main-kara-ke-main-dooron-dooron-paresh-pahuja-punjabi-56qgdGiY?utm_source=share&utm_medium=web&utm_name=list";

  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    const onCanPlay = () => setLoading(false);
    a.addEventListener("canplay", onCanPlay);
    return () => a.removeEventListener("canplay", onCanPlay);
  }, []);

  const toggle = async () => {
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) {
      try {
        await a.play();
        setPlaying(true);
      } catch (err) {
        console.error("Play failed", err);
      }
    } else {
      a.pause();
      setPlaying(false);
    }
  };

  return (
    <div className="fixed top-6 right-6 z-50">
      <audio ref={audioRef} src={songUrl} loop crossOrigin="anonymous" />
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={toggle}
        className={`flex items-center gap-3 px-6 py-3 rounded-full shadow-2xl transition-all duration-500 ${
          playing
            ? "bg-primary text-white scale-105"
            : "bg-white/80 text-primary backdrop-blur-md"
        }`}
      >
        <div
          className={`relative flex items-center justify-center w-8 h-8 rounded-full ${playing ? "bg-white/20" : "bg-primary/10"}`}
        >
          {playing ? (
            <div className="flex items-end gap-[2px] h-3">
              {[1, 2, 3, 4].map((i) => (
                <motion.div
                  key={i}
                  animate={{ height: [4, 12, 4] }}
                  transition={{
                    duration: 0.5,
                    repeat: Infinity,
                    delay: i * 0.1,
                  }}
                  className="w-[3px] bg-current rounded-full"
                />
              ))}
            </div>
          ) : (
            <Play className="w-4 h-4 fill-current ml-1" />
          )}
        </div>
        <span className="font-bold text-sm uppercase tracking-widest">
          {loading ? "loading..." : playing ? "shreya ki dhun" : "song suno ji"}
        </span>
      </motion.button>
    </div>
  );
}

export default function Valentine() {
  const slides: Slide[] = useMemo(
    () => [
      {
        id: "1",
        kicker: "heloo mairi janna",
        title: "aap maire liye sbse khaas ho",
        body: "shreya ji, aap marii life ki sbse bdi blessing ho. aaj valentines pr maine yai site sirf aapke liye bnayi hai.\n\naap pookie ho, aap mumma ho, aur aap mairi poori duniya ho. ji!",
        icon: Stars,
        accent: "primary",
      },
      {
        id: "2",
        kicker: "pookie vibes",
        title: "aapka wo pookie wala andaaz hayeee",
        body: "jab aap mujhse gussa hoti ho na cutie vla gussa, toh bhot zyada cute lagti ho.\n\naap mairi favorite notification ho, shreya ji.",
        icon: Heart,
        accent: "accent",
      },
      {
        id: "3",
        kicker: "mumma care",
        title: "aapki mumma vli care",
        body: "janna, jis trh aap mairi fikr krti hona, wo koi nhi kr skta. aap bilkul ek mumma ki trh maira dhyn rkhti ho.\n\ni feel so safe with you, ji.",
        icon: Coffee,
      },
      {
        id: "4",
        kicker: "janna ji",
        title: "aap mairi janna ho hmesha ke liye",
        body: "shreya, aapka maira rishta bhot hi mst hai. main chata hu hm hmesha ase hi ek dusre kai pookie bne rhe.\n\naap bas muskurati rhiye, ji.",
        icon: MessageCircle,
        accent: "primary",
      },
      {
        id: "5",
        kicker: "graphics love",
        title: "itni sundar ho ki graphics fail hain",
        body: "maine yhan bhot sre graphics add kre hai, pr aapki natural beauty kai aage sb fake hai. aap meri real-life hello kitty ho.\n\nso soft, so sweet sp softt umm hmmm hehehe!",
        icon: Sparkles,
      },
      {
        id: "6",
        kicker: "pookie world",
        title: "hmari apni ek pookie duniya",
        body: "main chata hu hm hmesha ase hi chhoti-chhoti baaton ar khush hote rhe. aap meri happiness ka remote control ho ji.\n\npress play on my heart!",
        icon: Gift,
        accent: "accent",
      },
      {
        id: "7",
        kicker: "vada",
        title: "ek chhota sa vada aapse",
        body: "mai hmesha aapka sth dunga, hmesha aapko protect krunga, aur hmesha aapka pookie bnk rahunga.\n\naap kabhi akela feel mt karna mairi mumma ji.",
        icon: Heart,
      },
      {
        id: "8",
        kicker: "spne",
        title: "hmare bht sre pookie spne",
        body: "travel krna, bht sra khana khana, aur hmesha ek dusre ko 'kannu' aur 'janna' bolte rhna. hmara future bht bright hai shreya ji.\n\nbas aap sth chahiye!",
        icon: Stars,
        accent: "primary",
      },
      {
        id: "9",
        kicker: "love you",
        title: "i love you to the moon and back apki vli line",
        body: "mumma, aap maire liye oxygen jaisi ho. aapke bina sb empty hai. aap mairi mumma wali side ho, aap mairi pookie vli side ho.\n\naap mairi sab kuch ho, ji.",
        icon: Sparkles,
      },
      {
        id: "10",
        kicker: "hmesha",
        title: "happy valentine's day janna ji",
        body: "ye site toh bs ek chhota sa gift hai, maira poora dil toh phele hi aapka hai. hmesha ase hi rhna, mairi mumma and janna.\n\ni love youuu spp much, ji!",
        icon: Heart,
        accent: "accent",
      },
    ],
    [],
  );

  const [index, setIndex] = useState(0);
  const total = slides.length;
  const current = slides[index];

  const next = () => setIndex((prev) => (prev + 1) % total);
  const prev = () => setIndex((prev) => (prev - 1 + total) % total);

  useKeyNav(prev, next);

  return (
    <div className="min-h-screen w-full bg-[#fff5f8] selection:bg-primary/20 overflow-hidden flex flex-col">
      <BackgroundHearts />
      <AudioControl />

      <main className="relative z-10 flex-1 flex flex-col items-center justify-center p-6 sm:p-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.8, y: 50, rotate: -5 }}
            animate={{ opacity: 1, scale: 1, y: 0, rotate: 0 }}
            exit={{ opacity: 0, scale: 1.1, y: -50, rotate: 5 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-3xl glass rounded-[40px] p-8 sm:p-16 relative overflow-hidden group shadow-[0_32px_128px_-16px_rgba(255,107,157,0.3)]"
          >
            {/* Animated corner decorations */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute -top-12 -right-12 w-48 h-48 bg-primary/5 rounded-full blur-3xl"
            />
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
              className="absolute -bottom-12 -left-12 w-48 h-48 bg-accent/5 rounded-full blur-3xl"
            />

            <div className="relative z-10 flex flex-col items-center text-center">
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center gap-2 px-6 py-2 rounded-full bg-primary/10 text-primary font-black text-xs uppercase tracking-[0.3em] mb-8"
              >
                <current.icon className="w-4 h-4" />
                {current.kicker}
              </motion.div>

              <motion.h1
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="font-display text-4xl sm:text-6xl font-black mb-8 leading-[1.1] tracking-tighter"
              >
                <span
                  className={current.accent ? "text-shine" : "text-slate-900"}
                >
                  {current.title}
                </span>
              </motion.h1>

              <motion.p
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-lg sm:text-2xl text-slate-600 font-medium leading-relaxed max-w-2xl whitespace-pre-line mb-12"
              >
                {current.body}
              </motion.p>

              <div className="flex flex-col sm:flex-row items-center gap-6 w-full justify-center">
                <div className="flex gap-4">
                  <motion.button
                    whileHover={{ scale: 1.1, x: -5 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={prev}
                    className="w-14 h-14 rounded-full border-2 border-primary/20 flex items-center justify-center text-primary transition-colors hover:bg-primary/5 shadow-lg bg-white"
                  >
                    <Heart className="w-6 h-6 rotate-180 fill-primary/10" />
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={next}
                    className="px-12 h-14 rounded-full bg-gradient-to-r from-primary to-accent text-white font-black text-lg shadow-[0_20px_40px_-12px_rgba(255,107,157,0.5)] flex items-center gap-3"
                  >
                    Next Slide Ji
                    <motion.div
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1, repeat: Infinity }}
                    >
                      →
                    </motion.div>
                  </motion.button>
                </div>
              </div>

              <div className="mt-12 flex items-center gap-3">
                {Array.from({ length: total }).map((_, i) => (
                  <motion.div
                    key={i}
                    animate={{
                      width: i === index ? 32 : 12,
                      opacity: i === index ? 1 : 0.2,
                      backgroundColor: i === index ? "#ff0080" : "#000",
                    }}
                    className="h-3 rounded-full cursor-pointer"
                    onClick={() => setIndex(i)}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        <div className="mt-12 flex gap-12 items-end">
          <FloatingElement delay={0} duration={3}>
            <img
              src={pookieCatImg}
              alt="pookie"
              className="h-32 sm:h-48 drop-shadow-2xl"
            />
          </FloatingElement>
          <FloatingElement delay={1} duration={4}>
            <img
              src={stickersImg}
              alt="stickers"
              className="h-24 sm:h-36 drop-shadow-xl"
            />
          </FloatingElement>
        </div>
      </main>

      <footer className="p-8 flex flex-col items-center gap-2 relative z-10">
        <p className="font-black text-xs uppercase tracking-[0.5em] text-primary/40 flex items-center gap-3">
          Made for Shreya <Heart className="w-3 h-3 fill-current" /> Forever Ji
        </p>
      </footer>
    </div>
  );
}
